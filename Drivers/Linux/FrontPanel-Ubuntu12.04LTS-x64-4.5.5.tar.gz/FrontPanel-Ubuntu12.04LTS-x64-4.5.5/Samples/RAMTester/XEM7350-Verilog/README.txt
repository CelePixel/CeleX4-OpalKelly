Opal Kelly RAMTester Sample (Xilinx)
------------------------------------
This sample uses the Memory Interface Generator (MIG) in the Xilinx ISE and
Vivado to test the memory of a FrontPanel-enabled device.


HDL Sources for RAMTester in Xilinx ISE
----------------------------------------
  -ramtest.v
  -ddr3_test.v
  -Core/*
  -MIG/*
  -xem7350-KXXXT.ucf


HDL Sources for RAMTester in Vivado
-----------------------------------
  -ramtest_Vivado.v
  -ddr3_test.v
  -Core/*
  -MIG_Vivado_KXXXT/*
  -xem7350-KXXXT.xdc

After copying your source files to a work folder, rename ramtest_Vivado.v
to ramtest.v.