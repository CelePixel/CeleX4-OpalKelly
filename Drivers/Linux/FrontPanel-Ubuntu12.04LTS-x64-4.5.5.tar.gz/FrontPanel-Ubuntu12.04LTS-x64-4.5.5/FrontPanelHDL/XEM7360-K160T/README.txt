ISE Version: Xilinx ISE 14.7
Architecture: Kintex-7
Target(s): XEM7360-K160T
