ISE Version: Xilinx ISE 13.3
Architecture: Kintex-7
Target(s): XEM7350-K70T
