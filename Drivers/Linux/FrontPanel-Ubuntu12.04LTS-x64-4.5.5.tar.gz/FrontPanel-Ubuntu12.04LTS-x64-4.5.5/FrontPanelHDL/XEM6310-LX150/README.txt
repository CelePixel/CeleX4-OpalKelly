ISE Version: Xilinx ISE 13.3
Architecture: Spartan-6
Target(s): XEM6310-LX150
