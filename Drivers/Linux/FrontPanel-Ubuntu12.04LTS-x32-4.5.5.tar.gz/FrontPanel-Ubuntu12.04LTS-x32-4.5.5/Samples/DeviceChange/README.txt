DeviceChange Sample
===================
This sample illustrates how to use operating system-specific messages to 
detect when USB devices are attached or unattached to the system.  It is the
application's responsibility to detect these events and properly manage
instances of the okCFrontPanel class.

At this time, this sample is only available on the Windows platform.

A device is only accessible in one application at a time. Ensure the 
FrontPanel application is closed before running the sample.  
