ISE Version: Xilinx ISE 13.1
Architecture: Spartan-6
Target(s): XEM6006
