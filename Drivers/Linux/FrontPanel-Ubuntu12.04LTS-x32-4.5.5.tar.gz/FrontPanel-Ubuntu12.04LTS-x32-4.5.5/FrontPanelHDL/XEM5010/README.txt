ISE Version: Xilinx ISE 10.2
Architecture: Virtex-5
Target(s): XEM5010
