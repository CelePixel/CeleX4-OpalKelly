ISE Version: Xilinx ISE 10.2
Architecture: Spartan-3
Target(s): XEM3001, XEM3005, XEM3010, XEM3050
